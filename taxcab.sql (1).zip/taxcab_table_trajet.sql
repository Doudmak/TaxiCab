
-- --------------------------------------------------------

--
-- Structure de la table `trajet`
--

DROP TABLE IF EXISTS `trajet`;
CREATE TABLE IF NOT EXISTS `trajet` (
  `adressedep` varchar(100) NOT NULL,
  `villedep` varchar(100) NOT NULL,
  `codepdep` int NOT NULL,
  `adressearr` varchar(100) NOT NULL,
  `villear` varchar(100) NOT NULL,
  `codeparr` varchar(100) NOT NULL,
  `prix` int NOT NULL,
  `num_trajet` int NOT NULL AUTO_INCREMENT,
  `mail` varchar(100) DEFAULT NULL,
  `km` int DEFAULT NULL,
  PRIMARY KEY (`num_trajet`),
  KEY `fk_mail` (`mail`)
) ENGINE=InnoDB AUTO_INCREMENT=325 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `trajet`
--

INSERT INTO `trajet` (`adressedep`, `villedep`, `codepdep`, `adressearr`, `villear`, `codeparr`, `prix`, `num_trajet`, `mail`, `km`) VALUES
('5 allée du square', 'Le Perreux sur marne', 94170, '7 rue de la seine', 'Orly', '94500', 17, 1, 'ulric.sieys@gmail.com', 8),
('7 rue des lilas', 'La Courneuve', 93000, '18 rue du général leclerc', 'Noisy-le-sec', '93700', 24, 2, 'ulric.sieys@gmail.com', 22),
('8 allée de la marne', 'Nogent sur Marne', 94120, '18 rue du général de gaulle', 'Le Perreux sur Marne', '94170', 12, 3, 'ulric.sieys@gmail.com', 5),
('8 route des sans culottes', 'Le Raincy', 94000, '8 avenue des choux', 'Villiers-sur-Marne', '93700', 24, 4, 'yanis.mkd@gmail.com', 13),
('56 rue de 11 juillet 1789', 'Livry', 93500, '8 avenue des carottes', 'Livry', '93500', 14, 5, 'yanis.mkd@gmail.com', 2),
('78 avenue des lapins', 'Sevran', 94270, '90 rue de la bergerie', 'Ile aux loups', '94180', 38, 6, 'yanis.mkd@gmail.com', 17),
('70 rue de genral de gaulle matinale', 'Herblay et loire', 63890, 'Lip balm', 'Marseille', '13000', 40, 7, 'yanis.mkd@gmail.com', 5),
('Place du theron', 'Fayet', 12300, 'Place de la pétanque', 'Camares', '12360', 30, 8, 'ulric.sieys@gmail.com', 14),
('Boulevard du Général Gallieni', 'Bry-sur-Marne', 94360, 'Allée du Square', 'Le-Perreux-sur-Marne', '94170', 4, 9, 'ulric.sieys@gmail.com', 3),
('Rue de Lauzac', 'Bordeaux', 33000, 'Rue de l\'Orme Saint-Simeon', 'Créteil', '94000', 0, 10, 'ulric.sieys@gmail.com', 0),
('Rue de l\'Orme Saint-Simeon', 'Créteil', 94000, 'Rue de la Marne', 'Le', 'Perreux-sur-Marne', 0, 11, 'ulric.sieys@gmail.com', 0),
('Allée du Jura', 'Auxerre', 89000, 'Rue de l\'Orme Saint-Simeon', 'Créteil', '94000', 0, 12, 'ulric.sieys@gmail.com', 0),
('Allée du Jura', 'Auxerre', 89000, 'Rue de l\'Orme Saint-Simeon', 'Créteil', '94000', 217, 13, 'ulric.sieys@gmail.com', 168),
('Allée du Jura', 'Auxerre', 89000, 'Rue de l\'Orme Saint-Simeon', 'Créteil', '94000', 0, 14, 'ulric.sieys@gmail.com', 0),
('Allée du Jura', 'Auxerre', 89000, 'Rue de l\'Orme Saint-Simeon', 'Créteil', '94000', 0, 15, 'ulric.sieys@gmail.com', 0),
('Ashmont Street', 'Melrose', 2176, 'Allée du Square', 'Vaulx-en-Velin', '69120', 0, 16, 'ulric.sieys@gmail.com', 0);
