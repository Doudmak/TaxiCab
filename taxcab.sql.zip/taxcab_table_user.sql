
-- --------------------------------------------------------

--
-- Structure de la table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `nom` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `adresse` varchar(100) NOT NULL,
  `ville` varchar(100) NOT NULL,
  `codePostal` int NOT NULL,
  `mail` varchar(100) NOT NULL,
  `mdp` varchar(100) NOT NULL,
  PRIMARY KEY (`mail`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`nom`, `prenom`, `adresse`, `ville`, `codePostal`, `mail`, `mdp`) VALUES
('Zizou', 'Zinedine', 'Rue de la coupe du monde', 'Aller les bleus', 75000, '', 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'),
('Pitt', 'Brad', '31 allée du plus beau', 'Broadway', 56789, 'brad.pitt@star.com', 'bradinou'),
('hola', 'QUETAL', 'rUE DE LA MARNE', 'le perreux', 94170, 'cocou@gmail.com', 'bonjour'),
('Vers', 'Matteo', '128 Avenue Paul Doumer', 'Villeneuve le roi', 94290, 'ihjvihv@gamail.com', 'coucou'),
('Vers', 'Matteo', '128 Avenue Paul Doumer', 'Villeneuve le roi', 94290, 'mathsyck@gmail.com', 'matteo1609'),
('SRIJ', 'SALMA', 'RUE DE TA MERE', 'UNE VILLE', 90000, 'ss@gmail.com', 'DIIZJEIDDJ84843030?'),
('Siey', 'Ulric', '5 allée du square', 'Le Perreux sur Marne', 94170, 'ulric.sieys@gmail.com', '1112'),
('Yanis', 'Makdoud', 'Rue de l\'AK47', 'Sevran', 93270, 'yanis.mkd@gmail.com', 'b6301935b19c9440a490ecd64ef2da7a9894fca80f9b00ae8ea714f0ae44019c'),
('Zizou', 'Zinedine', 'Rue de la coupe du monde', 'Aller les bleus', 75000, 'zizou.son.gros.crane@gmail.com', '1816c03d2ba7f6df08c4a98e0e9301724fcc23e9177416304227a125301ebc8c');
