
-- --------------------------------------------------------

--
-- Structure de la table `trajet`
--

DROP TABLE IF EXISTS `trajet`;
CREATE TABLE IF NOT EXISTS `trajet` (
  `adressedep` varchar(100) NOT NULL,
  `villedep` varchar(100) NOT NULL,
  `codepdep` int NOT NULL,
  `adressearr` varchar(100) NOT NULL,
  `villear` varchar(100) NOT NULL,
  `codeparr` varchar(100) NOT NULL,
  `prix` int NOT NULL,
  `num_trajet` int NOT NULL,
  `mail` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`num_trajet`),
  KEY `fk_mail` (`mail`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
