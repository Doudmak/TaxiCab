
-- --------------------------------------------------------

--
-- Structure de la table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `nom` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `adresse` varchar(100) NOT NULL,
  `ville` varchar(100) NOT NULL,
  `codePostal` int NOT NULL,
  `mail` varchar(100) NOT NULL,
  `mdp` varchar(100) NOT NULL,
  PRIMARY KEY (`mail`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`nom`, `prenom`, `adresse`, `ville`, `codePostal`, `mail`, `mdp`) VALUES
('Pitt', 'Brad', '31 allée du plus beau', 'Broadway', 56789, 'brad.pitt@star.com', 'bradinou'),
('hola', 'QUETAL', 'rUE DE LA MARNE', 'le perreux', 94170, 'cocou@gmail.com', 'bonjour'),
('Vers', 'Matteo', '128 Avenue Paul Doumer', 'Villeneuve le roi', 94290, 'ihjvihv@gamail.com', 'coucou'),
('Vers', 'Matteo', '128 Avenue Paul Doumer', 'Villeneuve le roi', 94290, 'mathsyck@gmail.com', 'matteo1609'),
('SRIJ', 'SALMA', 'RUE DE TA MERE', 'UNE VILLE', 90000, 'ss@gmail.com', 'DIIZJEIDDJ84843030?'),
('Siey', 'Ulric', '5 allée du square', 'Le Perreux sur Marne', 94170, 'ulric.sieys@gmail.com', '1112');
