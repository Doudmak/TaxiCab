
-- --------------------------------------------------------

--
-- Structure de la table `conducteur`
--

DROP TABLE IF EXISTS `conducteur`;
CREATE TABLE IF NOT EXISTS `conducteur` (
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `numPermis` int NOT NULL,
  `dateObtention` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `adresse` varchar(100) NOT NULL,
  `numImmat` int NOT NULL,
  `ville` varchar(100) NOT NULL,
  `codeP` int NOT NULL,
  `mdp` varchar(100) NOT NULL,
  `mail` varchar(100) NOT NULL,
  PRIMARY KEY (`mail`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `conducteur`
--

INSERT INTO `conducteur` (`nom`, `prenom`, `numPermis`, `dateObtention`, `adresse`, `numImmat`, `ville`, `codeP`, `mdp`, `mail`) VALUES
('Ulric', 'Sieys', 567890, '98765', '7987', 987654, 'klnvrln', 9087, '98765@gmail.com', 'flashjet\'aime');
